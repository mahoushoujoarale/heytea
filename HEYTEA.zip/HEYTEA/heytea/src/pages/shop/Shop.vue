<template>
<div id="shop">百货</div>
</template>

<script>
export default {
  name: 'Shop'
}
</script>

<style scoped>
#shop {
  width: 100%;
  height: 100%;
  background-color: orange;
}
</style>