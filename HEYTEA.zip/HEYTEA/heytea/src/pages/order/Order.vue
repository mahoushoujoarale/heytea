<template>
<div id="order">订单</div>
</template>

<script>
export default {
  name: 'Order'
}
</script>

<style scoped>
#order {
  width: 100%;
  height: 100%;
  background-color: purple;
}
</style>