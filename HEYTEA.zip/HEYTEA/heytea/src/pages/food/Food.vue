<template>
<div id="food">
  <div>点单</div>
</div>
</template>

<script>
export default {
  name: 'Food'
}
</script>

<style scoped>
#food {
  width: 100%;
  height: 100%;
  background-color: green;
}
</style>